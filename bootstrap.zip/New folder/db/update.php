<?php
   include"connection.php";

	$id = $_GET['id'];
	$x = "SELECT * From userinfo Where id ='$id'"; 
	
	$sql =mysql_query($x);
	if(!$sql){
		echo mysql_error();
		}
		else{
			$data = mysql_fetch_array($sql);
			}
?>
    	<form action="" method="post">
        Name: <input type="text" name="name" value="<?php echo $data['name']; ?>" />
        PASSWORD: <input type="text" name="pass" value="<?php echo $data['password']; ?>" />
              <input type="submit" name="btn" />
        </form>
<?php
	if(isset($_POST['btn'])){
    	$name = $_POST['name'];
		$pass = $_POST['pass'];
			
			$update = "UPDATE userinfo set name = '$name', password = '$pass' where id = '$id'  ";
			$sql =mysql_query($update);
			if(!$sql){
		echo mysql_error();
		}
		else{
			header('refresh:3;url=fetch.php');
			}

			
			}

	 
	 ?>
    
    
    
    
    
    
    
    
    
    
     