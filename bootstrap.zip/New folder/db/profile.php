<?php
session_start();
include "connection.php";
if(isset($_SESSION['id'])){
	$id=$_SESSION['id'];
	$login="SELECT * FROM userinfo WHERE id ='$id'";
	$sql=mysql_query($login);
	if(!$sql){
		echo mysql_error();
	}
	else{
		$data =mysql_fetch_array($sql);
	}
}
?>

<?php
if(isset($data['name'])){
	?>
	<div style="width:200px; height:200px; margin:auto; background-color:#9FF">
    <b>WELCOME <?php echo $data['name']; ?> To THE PROFILE </b>
    </div>
    <?php }?>