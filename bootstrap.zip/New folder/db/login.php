<?php
session_start();
include "connection.php";
?>
<form method="post" action="">
Name:<input type="text" name="name"/>
<br/>
Pass:<input type="text" name="pass"/>
<br/>
<input type="submit"/>
</form>

<?php
if($_POST){
	$name=$_POST['name'];
	$pass=$_POST['pass'];
	
	
	$login="SELECT * FROM userinfo WHERE name= '$name' and password ='$pass'";
	$sql = mysql_query($login);
	
	if(!$sql){
		echo mysql_error();
	}
	else{
		$data= mysql_fetch_array($sql);
		if($name==$data['name'] && $pass==['password']){
			echo"Inside If";
			$_SESSION['id']=$data['id'];
			
			?>
           <script>
		   window.location="profile.php";
		   </script>
		               <?php
		}
		else{
			echo "Username or Password is wrong";
		}
	}
}
?>