<?php
include "connection.php";
$name=$_POST['name'];
$pass=$_POST['pass'];

$insert="INSERT INTO userinfo (name,password) Values ('$name','$pass');";
$sql=mysql_query($insert);

if($sql){
		echo"Data has been inserted";
	header('refresh:2;url=form.html');
	
}
else{

echo mysql_error();
}
?>