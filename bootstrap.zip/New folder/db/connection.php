<?php



	$con = @mysql_connect('localhost','root','');
	$sql = @mysql_select_db('first',$con);
	
		if(!$sql){
			echo mysql_error();
			}
			else{
			echo "<span style='color:green'> Connection Established </span>";	
				}
			
			

?>