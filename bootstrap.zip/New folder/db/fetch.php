<?php

	include"connection.php";
?>
	<table border="1px" cellspacing="0px">
    	<tr>
        	<td>NAME</td>
            <td>PASSWORD</td>
            <td><span style="color:green">UPDATE</span></td>
            <td><span style="color:red"> DELETE</span></td>
        </tr>    
<?php 		
	$fetch = "SELECT * FROM userinfo";
	$sql = mysql_query($fetch);
	
			if(!$sql){
			echo mysql_error();	
					 }
			else{
			while($data = mysql_fetch_array($sql)){
?>
            <tr>
            <td><?php echo $data['name']; ?></td>
            <td><?php echo $data['password']; ?></td>     
            <td><a href="update.php?id=<?php  echo $data['id']; ?>"><input type="submit" value="Update" style="color:blue"/></a></td>
            <td><a href="delete.php?id=<?php  echo $data['id']; ?>"><input type="submit" value="Delete" style="color:red"/></a></td>   
            </tr>
             <?php
			 }
			}			
			?>        
</table>