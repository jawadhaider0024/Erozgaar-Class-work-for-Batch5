<?php
include "connection.php";
	$id = $_GET['id'];

	$delete = "DELETE FROM userinfo where id = '$id'  ";
	
	$sql =mysql_query($delete);
	if(!$sql){
		echo mysql_error();
		}
		else{
				header('refresh:1;url=fetch.php');
			}


?>